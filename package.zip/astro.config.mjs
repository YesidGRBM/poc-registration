// @ts-check
import { defineConfig, envField } from 'astro/config';

import tailwindcss from '@tailwindcss/vite';
import svelte from '@astrojs/svelte';

import node from '@astrojs/node'

// https://astro.build/config
export default defineConfig({
  output: 'server',
  devToolbar: {
    enabled: false,
  },
  env: {
    schema: {
      URL_SERVER: envField.string({context: 'server', access: 'public', default: 'https://poc-registration-services-production.up.railway.app' })
    }
  },
  vite: {
    plugins: [tailwindcss()],
  },
  integrations: [svelte()],
  adapter: node({
    mode: 'standalone'
  }),
  server: {
    host: true
  }
});


// cloudflare({
//   platformProxy: {
//     enabled: true,
//   },
// })
